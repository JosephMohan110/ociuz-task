
from django.db import connection, transaction


# PRIVATE HELPERS

def _fetchall(cursor):
    # """Convert cursor result-set to a list of dicts."""
    cols = [c[0] for c in cursor.description]
    return [dict(zip(cols, row)) for row in cursor.fetchall()]


def _fetchone(cursor):
    # """Convert a single cursor row to a dict, or return None."""
    row = cursor.fetchone()
    if row is None:
        return None
    cols = [c[0] for c in cursor.description]
    return dict(zip(cols, row))


def db_get_course_id(course_name):
    # """Return the active course_id for a given course name, or None if no match."""
    with connection.cursor() as cur:
        cur.execute(
            "SELECT course_id FROM tblCourse WHERE course_name = %s AND status = 'Active'",
            [course_name]
        )
        row = cur.fetchone()
        return row[0] if row else None


# READ — list & detail

def db_get_all_students(search_keyword=''):
    # """
    # Return every student joined with their latest approval status.
    # When search_keyword is given, filters across name / phone / email / course.
    # Returns a list of dicts ordered by id DESC (newest first).
    # """
    with connection.cursor() as cur:
        cur.execute(
            "SELECT * FROM fnGetStudentsWithStatus(%s)",
            [search_keyword or None]
        )
        return _fetchall(cur)


def db_get_student_by_id(student_id):
    # """
    # Return one student (with latest approval status and image path) or None.
    # """
    with connection.cursor() as cur:
        cur.execute(
            """
            SELECT
                s.id,
                s.name,
                s.phone,
                s.email,
                s.course_id,
                COALESCE(c.course_name, 'Unknown') AS course,
                s.student_image,
                s.created_date,
                s.updated_date,
                COALESCE(a.approval_status, 'Pending') AS approval_status,
                COALESCE(a.approved_by, 'System') AS approved_by,
                COALESCE(a.remarks, '') AS remarks,
                a.approved_date
            FROM students s
            LEFT JOIN tblCourse c ON s.course_id = c.course_id
            LEFT JOIN LATERAL (
                SELECT sa.approval_status, sa.approved_by, sa.remarks, sa.approved_date
                FROM student_approval sa
                WHERE sa.student_id = s.id
                ORDER BY sa.id DESC
                LIMIT 1
            ) a ON TRUE
            WHERE s.id = %s
            LIMIT 1
            """,
            [student_id]
        )
        return _fetchone(cur)


# READ — email uniqueness check

def db_email_exists(email, exclude_id=None):
    # """
    # Return True if email is already taken.
    # Pass exclude_id when editing so the student's own email is not flagged.
    # """
    with connection.cursor() as cur:
        if exclude_id:
            cur.execute(
                "SELECT COUNT(*) FROM students WHERE email = %s AND id != %s",
                [email, exclude_id]
            )
        else:
            cur.execute(
                "SELECT COUNT(*) FROM students WHERE email = %s",
                [email]
            )
        return cur.fetchone()[0] > 0


# CREATE

def db_add_student(name, phone, email, course, student_image_path=None):
    # """
    # INSERT a new student and an initial 'Pending' approval record.
    # Both writes happen inside one atomic transaction.
    # Returns the new student id.
    # """
    course_id = db_get_course_id(course)
    with transaction.atomic():
        with connection.cursor() as cur:
            cur.execute(
                "SELECT fnAddStudent(%s, %s, %s, %s, %s)",
                [name, phone, email, course_id, student_image_path]
            )
            return cur.fetchone()[0]


# UPDATE

def db_update_student(student_id, name, phone, email, course, student_image_path=None):
    # """
    # UPDATE core student fields.
    # ANY edit automatically resets the student to 'Pending' status
    # so they go back into the approval queue for re-review.
    # Returns True if the student row was updated, False otherwise.
    # """
    course_id = db_get_course_id(course)
    with transaction.atomic():
        with connection.cursor() as cur:
            cur.execute(
                "SELECT fnEditStudent(%s, %s, %s, %s, %s, %s)",
                [student_id, name, phone, email, course_id, student_image_path]
            )
            return cur.fetchone()[0]


# DELETE

def db_delete_student(student_id):
    # """
    # DELETE a student and ALL related approval records.
    # Returns True if the student row was deleted.
    # """
    with connection.cursor() as cur:
        cur.execute(
            "SELECT fnDeleteStudent(%s)",
            [student_id]
        )
        return cur.fetchone()[0]


# APPROVE

def db_approve_student(student_id, approved_by='Admin', remarks=''):
    # """
    # Insert an 'Approved' record into student_approval.
    # Returns True on success.
    # """
    with transaction.atomic():
        with connection.cursor() as cur:
            cur.execute(
                "SELECT fnApproveStudent(%s, %s, %s)",
                [student_id, approved_by, remarks]
            )
            return cur.fetchone()[0]


# REJECT

def db_reject_student(student_id, approved_by='Admin', remarks=''):
    # """
    # Insert a 'Rejected' record into student_approval.
    # Returns True on success.
    # """
    with transaction.atomic():
        with connection.cursor() as cur:
            cur.execute(
                "SELECT fnRejectStudent(%s, %s, %s)",
                [student_id, approved_by, remarks]
            )
            return cur.fetchone()[0]


# APPROVAL HISTORY  (full audit trail)

def db_get_approval_history(student_id):
    # """
    # Return every approval/rejection event for a student, newest first.
    # Each dict: id, approval_status, approved_by, remarks, approved_date.
    # """
    with connection.cursor() as cur:
        cur.execute(
            "SELECT * FROM fnGetApprovalHistory(%s)",
            [student_id]
        )
        return _fetchall(cur)


# COURSES

def db_get_courses():
    # """
    # Return all active courses.
    # Each dict: course_id, course_name, course_code, status.
    # """
    with connection.cursor() as cur:
        cur.execute(
            "SELECT * FROM fnGetCourses()"
        )
        return _fetchall(cur)


def db_course_exists(course_code):
    # """
    # Return True if a course with the given code exists and is active.
    # """
    with connection.cursor() as cur:
        cur.execute(
            "SELECT COUNT(*) FROM tblCourse WHERE course_code = %s AND status = 'Active'",
            [course_code]
        )
        return cur.fetchone()[0] > 0
