# urls.py — Student app URL patterns

from django.urls import path
from . import views

urlpatterns = [
    path('',views.student_list,name='student_list'),
    path('add/',views.add_student,name='add_student'),
    path('edit/<int:student_id>/',views.edit_student,name='edit_student'),
    path('delete/<int:student_id>/',views.delete_student,name='delete_student'),
    path('approve/<int:student_id>/',views.approve_student,name='approve_student'),
    path('reject/<int:student_id>/',views.reject_student,name='reject_student'),
    path('history/<int:student_id>/',views.view_approval_history,name='approval_history'),
    path('api/search/',views.search_students_api,name='search_api'),
]