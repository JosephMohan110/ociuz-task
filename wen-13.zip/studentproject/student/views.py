# views.py
# ─────────────────────────────────────────────────────────────
# All HTTP request handling for the Student app.
# No ORM / database code here — every DB call goes through db_functions.py.
# ─────────────────────────────────────────────────────────────

import re
from django.shortcuts import render, redirect
from django.contrib import messages
from django.core.paginator import Paginator
from django.http import JsonResponse

from .db_functions import (
    db_get_all_students,
    db_get_student_by_id,
    db_email_exists,
    db_add_student,
    db_update_student,
    db_delete_student,
    db_approve_student,
    db_reject_student,
    db_get_approval_history,
    db_get_courses,
    db_course_exists,
)


# SHARED FORM VALIDATION

def _validate_form(request, name, phone, email, course, exclude_id=None):
    # """
    # Validate student form fields.
    # Adds a django error-message for every problem found.
    # Returns True if ANY field is invalid (has_error), False if all OK.
    # """
    has_error = False

    # Name
    if not name:
        messages.error(request, 'Name is required.')
        has_error = True
    elif not re.match(r'^[A-Za-z\s]+$', name):
        messages.error(request, 'Name must contain only letters and spaces.')
        has_error = True

    # Phone
    if not phone:
        messages.error(request, 'Phone number is required.')
        has_error = True
    elif not phone.isdigit() or len(phone) != 10:
        messages.error(request, 'Phone number must be exactly 10 digits.')
        has_error = True
    elif phone[0] not in '6789':
        messages.error(request, 'Phone number must start with 6, 7, 8 or 9.')
        has_error = True

    # Email
    if not email:
        messages.error(request, 'Email is required.')
        has_error = True
    elif not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
        messages.error(request, 'Enter a valid email address.')
        has_error = True
    elif db_email_exists(email, exclude_id=exclude_id):
        messages.error(request, 'This email is already registered.')
        has_error = True

    # Course
    if not course:
        messages.error(request, 'Course is required.')
        has_error = True
    elif not re.match(r'^[A-Za-z\s]+$', course):
        messages.error(request, 'Course name must contain only letters and spaces.')
        has_error = True
    elif not db_course_exists(course):
        messages.error(request, 'Selected course is not available in the course master list.')
        has_error = True

    return has_error


# STUDENT LIST  (READ — all students)

def student_list(request):
    # """
    # Display all students with their current approval status.
    # Supports search (name / phone / email / course) and pagination (5 per page).
    # """
    search_keyword = request.GET.get('search', '').strip()
    all_students   = db_get_all_students(search_keyword=search_keyword)

    paginator   = Paginator(all_students, 5)
    page_obj    = paginator.get_page(request.GET.get('page'))

    return render(request, 'student/student_list.html', {
        'students':       page_obj,
        'page_obj':       page_obj,
        'paginator':      paginator,
        'search_keyword': search_keyword,
    })


# ADD STUDENT  (CREATE)

def add_student(request):
    # """
    # GET   blank form.
    # POST  validate → INSERT student + Pending approval → redirect to list.
    # """
    form_data = {'name': '', 'phone': '', 'email': '', 'course': ''}
    courses = db_get_courses()

    if request.method == 'POST':
        name   = request.POST.get('name',   '').strip()
        phone  = request.POST.get('phone',  '').strip()
        email  = request.POST.get('email',  '').strip()
        course = request.POST.get('course', '').strip()

        form_data = {'name': name, 'phone': phone, 'email': email, 'course': course}

        if not _validate_form(request, name, phone, email, course):
            db_add_student(name, phone, email, course)
            messages.success(request, f'Student "{name}" added successfully.')
            return redirect('student_list')

    return render(request, 'student/add_student.html', {
        'form_data': form_data,
        'courses': courses,
    })


# EDIT STUDENT  (UPDATE)

def edit_student(request, student_id):
    # """
    # GET   form pre-filled with current student data.
    # POST  validate → UPDATE student → redirect to list.
    # ANY edit automatically resets status to Pending for re-approval.
    # """
    student = db_get_student_by_id(student_id)
    if not student:
        messages.error(request, 'Student not found.')
        return redirect('student_list')

    courses = db_get_courses()
    form_data = {
        'name':   student['name'],
        'phone':  student['phone'],
        'email':  student['email'],
        'course': student['course'],
    }

    if request.method == 'POST':
        name   = request.POST.get('name',   '').strip()
        phone  = request.POST.get('phone',  '').strip()
        email  = request.POST.get('email',  '').strip()
        course = request.POST.get('course', '').strip()

        form_data = {'name': name, 'phone': phone, 'email': email, 'course': course}

        if not _validate_form(request, name, phone, email, course, exclude_id=student_id):
            db_update_student(student_id, name, phone, email, course)

            messages.info(request,
                f'"{name}" updated successfully. Status reset to Pending for re-approval.')

            return redirect('student_list')

    return render(request, 'student/edit_student.html', {
        'student':   student,
        'form_data': form_data,
        'courses':   courses,
    })


# DELETE STUDENT  (DELETE)

def delete_student(request, student_id):
    # """
    # GET   confirmation page.
    # POST  DELETE student (and all approval records) → redirect.
    # """
    student = db_get_student_by_id(student_id)
    if not student:
        messages.error(request, 'Student not found.')
        return redirect('student_list')

    if request.method == 'POST':
        db_delete_student(student_id)
        messages.success(request, f'Student "{student["name"]}" deleted.')
        return redirect('student_list')

    return render(request, 'student/delete_student.html', {'student': student})


# APPROVE STUDENT

def approve_student(request, student_id):
    # """
    # GET   confirmation page with optional remarks.
    # POST  INSERT Approved record → redirect.
    # Only Pending students can be approved.
    # """
    student = db_get_student_by_id(student_id)
    if not student:
        messages.error(request, 'Student not found.')
        return redirect('student_list')

    if student['approval_status'] != 'Pending':
        messages.warning(request,
            f'"{student["name"]}" is already {student["approval_status"]}.')
        return redirect('student_list')

    if request.method == 'POST':
        remarks = request.POST.get('remarks', '').strip()
        db_approve_student(student_id, approved_by='Admin', remarks=remarks)
        messages.success(request, f'"{student["name"]}" approved successfully.')
        return redirect('student_list')

    return render(request, 'student/approve_student.html', {
        'student': student,
        'remarks': '',
    })


# REJECT STUDENT

def reject_student(request, student_id):
    # """
    # GET   confirmation page with optional remarks.
    # POST  INSERT Rejected record → redirect.
    # Only Pending students can be rejected.
    # """
    student = db_get_student_by_id(student_id)
    if not student:
        messages.error(request, 'Student not found.')
        return redirect('student_list')

    if student['approval_status'] != 'Pending':
        messages.warning(request,
            f'"{student["name"]}" is already {student["approval_status"]}.')
        return redirect('student_list')

    if request.method == 'POST':
        remarks = request.POST.get('remarks', '').strip()
        db_reject_student(student_id, approved_by='Admin', remarks=remarks)
        messages.success(request, f'"{student["name"]}" rejected.')
        return redirect('student_list')

    return render(request, 'student/reject_student.html', {
        'student': student,
        'remarks': '',
    })


# APPROVAL HISTORY  (VIEW AUDIT TRAIL)

def view_approval_history(request, student_id):
    # """
    # GET   display full approval/rejection history for a student.
    # Shows every event (Pending → Approved/Rejected) with timestamps and remarks.
    # """
    student = db_get_student_by_id(student_id)
    if not student:
        messages.error(request, 'Student not found.')
        return redirect('student_list')

    history = db_get_approval_history(student_id)

    return render(request, 'student/approval_history.html', {
        'student': student,
        'history': history,
    })


# REAL-TIME SEARCH (AJAX)

def search_students_api(request):
    # """
    # AJAX endpoint for real-time search.
    # Returns JSON with matching students.
    # GET parameter: ?q=search_keyword
    # """
    search_keyword = request.GET.get('q', '').strip()
    
    # Require minimum 1 character
    if len(search_keyword) < 1:
        return JsonResponse({'results': []})
    
    # Get matching students
    all_students = db_get_all_students(search_keyword=search_keyword)
    
    # Limit to first 20 results for performance
    results = []
    for student in all_students[:20]:
        results.append({
            'id': student['id'],
            'name': student['name'],
            'email': student['email'],
            'phone': student['phone'],
            'course': student['course'],
            'approval_status': student['approval_status'],
            'approved_by': student['approved_by'],
        })
    
    return JsonResponse({'results': results})